

#include "i2c_24c16.h"

//------------------------EEPROM 24Cxx API---------------------------
void i2c_24c_init(I2C_TypeDef *I2Cx)
{
        I2C_Cmd(I2Cx,DISABLE);
	I2C_InitTypeDef I2C_InitStruct;

	I2C_InitStruct.I2C_Mode = I2C_Mode_I2C;
	I2C_InitStruct.I2C_Ack = I2C_Ack_Enable;
	I2C_InitStruct.I2C_ClockSpeed = I2C_Speed;
	I2C_InitStruct.I2C_DutyCycle = I2C_DutyCycle_2;
	I2C_InitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
       // EEprom Block Select;
	I2C_InitStruct.I2C_OwnAddress1 = I2C_Slave_Adress7;

	I2C_Cmd(I2Cx,ENABLE);

	I2C_Init(I2Cx,&I2C_InitStruct);

}

void i2c_24c_byte_write(unsigned char Byte, unsigned char WriteAddr, unsigned int ByteToWrite, unsigned char EE24cBlockSelect,I2C_TypeDef *I2Cx)
{
	// Start the I2C
	I2C_GenerateSTART(I2Cx,ENABLE);

      //not recommanded, stupid way
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));

	I2C_Send7bitAddress(I2Cx,EE24cBlockSelect,I2C_Direction_Transmitter);

	// when get ACK, means Set Success
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

	I2C_SendData(I2Cx, WriteAddr);

	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

	I2C_SendData(I2Cx, Byte);

	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
	
	I2C_GenerateSTOP(I2Cx, ENABLE);
}

/*******************************************************************************
* Function Name  :i2c_24c_buffer_write
* Description    : 24c EE, buffer Write
* Input          : u8 *pBuffer--buffer for send, u8 Addr---Address to Write, u8 how many bytes to write, 
* Output         : None
* Return         : None
*******************************************************************************/
void i2c_24c_buffer_write(unsigned char *pBuffer, unsigned char WriteAddr, unsigned int ByteToWrite, unsigned char EE24cBlockSelect,I2C_TypeDef *I2Cx)
{
    unsigned char Pages=0;
    unsigned char Singles=0;
    unsigned char Addr;
    unsigned char count=0;
    unsigned int i;
   Addr = WriteAddr%I2C_Pagesize;
   count = I2C_Pagesize-Addr;
   Pages = ByteToWrite/I2C_Pagesize;
   Singles = ByteToWrite%I2C_Pagesize;

//Addr is Align to the PageSize
   if(Addr==0)
   	{
   		//bytes < pagesize
		if(Pages==0)
			{
				i2c_24c_page_wrtie(pBuffer, WriteAddr,ByteToWrite, EE24cBlockSelect,I2Cx);
                                for(i = 0; i < 120000; i++)
                                {}
				i2c_24c_wait(EE24cBlockSelect,I2Cx);
			}
		//bytes > pagesize
		else
			{
				while(Pages--)
					{
						i2c_24c_page_wrtie(pBuffer, WriteAddr,I2C_Pagesize,EE24cBlockSelect,I2Cx);
                                                for(i = 0; i < 120000; i++)
                                                {}
						i2c_24c_wait(EE24cBlockSelect,I2Cx);
						WriteAddr+=I2C_Pagesize;
						pBuffer+=I2C_Pagesize;
					}
						// Signles to Write
				if(Singles!=0)
					{
						i2c_24c_page_wrtie(pBuffer, WriteAddr,Singles,EE24cBlockSelect,I2Cx);
                                                for(i = 0; i < 120000; i++)
                                                {}
						i2c_24c_wait(EE24cBlockSelect,I2Cx);	
					}
		
			}

   	}
   else
   	{
		//byte to write < Pagesize
		if(Pages==0)
			{
				i2c_24c_page_wrtie(pBuffer, WriteAddr,Singles,EE24cBlockSelect,I2Cx);
				i2c_24c_wait(EE24cBlockSelect,I2Cx);		
			}
		else
			{
				ByteToWrite-=count;
				if(count!=0)
					{
						i2c_24c_page_wrtie(pBuffer, WriteAddr,count,EE24cBlockSelect,I2Cx);
						i2c_24c_wait(EE24cBlockSelect,I2Cx);
						WriteAddr+=count;
						pBuffer+=count;
					}

				while(Pages--)
					{
						i2c_24c_page_wrtie(pBuffer, WriteAddr,I2C_Pagesize,EE24cBlockSelect,I2Cx);
						i2c_24c_wait(EE24cBlockSelect,I2Cx);
						WriteAddr+=I2C_Pagesize;
						pBuffer+=I2C_Pagesize;
					}
						// Signles to Write
				if(Singles!=0)
					{
						i2c_24c_page_wrtie(pBuffer, WriteAddr,Singles,EE24cBlockSelect,I2Cx);
						i2c_24c_wait(EE24cBlockSelect,I2Cx);	
					}
				
			}
   	}

}

/*******************************************************************************
* Function Name  : i2c_24c_page_wrtie
* Description    : basic API, page Write
* Input          : u8 *pBuffer--buffer for send, u8 Addr---Address to Write, u8 how many bytes to write, 
* Output         : None
* Return         : None
*******************************************************************************/
void i2c_24c_page_wrtie(unsigned char *pBuffer, unsigned char Addr, unsigned char ByteToWrite,unsigned char EE24cBlockSelect, I2C_TypeDef *I2Cx)
{
	// Start the I2C
	I2C_GenerateSTART(I2Cx,ENABLE);

      //not recommanded, stupid way
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));

	I2C_Send7bitAddress(I2Cx,EE24cBlockSelect,I2C_Direction_Transmitter);

	// when get ACK, means Set Success
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

	I2C_SendData(I2Cx, Addr);

	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

	while(ByteToWrite--)
		{
			I2C_SendData(I2Cx, *pBuffer);

			pBuffer++;
			
			while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
			
		}
	
	I2C_GenerateSTOP(I2Cx, ENABLE);
}

/*******************************************************************************
* Function Name  : i2c_24c_page_wrtie
* Description    : basic API, page Write
* Input          : u8 *pBuffer--buffer for send, u8 Addr---Address to Write, u8 how many bytes to write, 
* Output         : None
* Return         : None
*******************************************************************************/
void i2c_24c_buffer_read(unsigned char *pBuffer, unsigned char Addr,unsigned  int NumToRead,unsigned char EE24cBlockSelect, I2C_TypeDef *I2Cx)
{
	//open I2C
	I2C_GenerateSTART(I2Cx, ENABLE);

	while(!(I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT)));

	I2C_Send7bitAddress(I2Cx,EE24cBlockSelect,I2C_Direction_Transmitter);

	while(!(I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));

	I2C_Cmd(I2Cx,ENABLE);

	I2C_SendData(I2Cx, Addr);

	while(!(I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));

	I2C_GenerateSTART(I2Cx, ENABLE);

	while(!(I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT)));

	I2C_Send7bitAddress(I2Cx,EE24cBlockSelect,I2C_Direction_Receiver);

	while(!(I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)));

	while(NumToRead)
		{
			if(NumToRead==1)
				{
					I2C_AcknowledgeConfig(I2Cx, DISABLE);

					I2C_GenerateSTOP(I2Cx, ENABLE);
				}

			if((I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED)))
				{
					*pBuffer = I2C_ReceiveData(I2Cx);

					pBuffer++;

					NumToRead--;
				}
		}

	I2C_AcknowledgeConfig(I2Cx, ENABLE);
	
}

/*******************************************************************************
* Function Name  : i2c_24c_wait
* Description    : Wait for EEPROM Standby state
* Input          : u8 EE24cBlockSelect --Area Select, I2C_TypeDef *I2Cx, which I2C to use
* Output         : None
* Return         : None
*******************************************************************************/
void i2c_24c_wait(unsigned char EE24cBlockSelect, I2C_TypeDef *I2Cx)
{
	I2C_GenerateSTART(I2Cx, ENABLE);

	while(!(I2C_ReadRegister(I2Cx, I2C_Register_SR1) & 0x0002))
	{
	    I2C_Send7bitAddress(I2Cx, EE24cBlockSelect, I2C_Direction_Transmitter);
	}

	I2C_ClearFlag(I2Cx, I2C_FLAG_AF);

	I2C_GenerateSTOP(I2Cx, ENABLE);
}

/*------------------------------End of File------------------------------------------*/
