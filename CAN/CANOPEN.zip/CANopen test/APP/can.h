#include "stm32f10x.h"

void CAN_Configration(u32 BaudRate);
void Crx(void);
void Ctx(void);
