#include "stm32f10x.h"

void Key_ReceiveODNodeID(void);
u8 Key_ReceiveBaudRate(void);
