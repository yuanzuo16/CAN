#include "stm32f10x.h"
#include "mco.h"
#include "can.h"

u8 gMessagePending;	
extern CAN_MSG gRxCAN;	

/****************************************************************************
* ���ƣ�CAN_Configration(s32 BaudRate)
* ���ܣ�CAN����
* ��ڲ�����BaudRate
* ���ڲ�������
****************************************************************************/
void CAN_Configration(u32 BaudRate)
{
  CAN_InitTypeDef CAN_InitStructure;
  
  CAN_DeInit(CAN1);
  CAN_StructInit(&CAN_InitStructure);
  //�ر�ʱ�䴥��ģʽ
  CAN_InitStructure.CAN_TTCM=DISABLE;
  //�ر��Զ����߹���
  CAN_InitStructure.CAN_ABOM=DISABLE;
  //�ر��Զ�����ģʽ
  CAN_InitStructure.CAN_AWUM=DISABLE;
  //��ֹ�����Զ��ش�
  CAN_InitStructure.CAN_NART=DISABLE;
  //FIFO ���ʱ���ĸ���Դ�ļ�
  CAN_InitStructure.CAN_RFLM=DISABLE;
  //���ķ������ȼ�ȡ����ID��
  CAN_InitStructure.CAN_TXFP=DISABLE;
  //�����Ĺ���ģʽ
  CAN_InitStructure.CAN_Mode=CAN_Mode_Normal;
  //����CAN ������=36000000/CAN_Prescaler/(CAN_SJW+CAN_BS1+CAN_BS2)
  switch(BaudRate)
  {
  case 1:
    CAN_InitStructure.CAN_SJW=CAN_SJW_2tq;//5
    CAN_InitStructure.CAN_BS1=CAN_BS1_6tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_4tq;
    CAN_InitStructure.CAN_Prescaler = 600;
    break;
  case 2:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//10
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 600;
    break;
  case 3:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//20
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 300;
    break;
  case 4:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//25
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 240;
    break;
  case 5:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//40
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 150;
    break;
  case 6:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//50
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 120;
    break;
    /**
  case 62.5:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 96;
    break;
    **/
  case 7:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//80
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 75;
    break;
  case 8:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//100
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 60;
    break;
  case 9:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//125
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 48;
    break;
  case 10:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//200
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 30;
    break;
  case 11:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//250
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 24;
    break;
  case 12:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//400
    CAN_InitStructure.CAN_BS1=CAN_BS1_5tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_3tq;
    CAN_InitStructure.CAN_Prescaler = 10;
    break;
  case 13:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//500
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 12;
    break;
  case 14:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//800
    CAN_InitStructure.CAN_BS1=CAN_BS1_5tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_3tq;
    CAN_InitStructure.CAN_Prescaler = 5;
    break;
  case 15:
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;//1000
    CAN_InitStructure.CAN_BS1=CAN_BS1_3tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
    CAN_InitStructure.CAN_Prescaler = 6;
    break;
  default:break;
  }
  //��ʼ��CAN
  CAN_Init(CAN1,&CAN_InitStructure);
  //ʹ�ܽ����ж�
  CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);
}
/****************************************************************************
* ���ƣ�Crx(void)
* ���ܣ�CAN��������
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void  Crx(void)
{
  u8 i;
  u32 DataL,DataH;
  for(i = 0; i < gMessagePending; i++)
  {
    CAN_Receive_UC(CAN1,CAN_FIFO0,(u32*)(&gRxCAN.ID), (u32*)(&gRxCAN.LEN), &DataH, &DataL);
    gRxCAN.BUF[0] = (u32)0x000000FF & DataL;
    gRxCAN.BUF[1] = (u32)0x000000FF & (DataL >> 8);
    gRxCAN.BUF[2] = (u32)0x000000FF & (DataL >> 16);
    gRxCAN.BUF[3] = (u32)0x000000FF & (DataL >> 24);
    
    gRxCAN.BUF[4] = (u32)0x000000FF & DataH;
    gRxCAN.BUF[5] = (u32)0x000000FF & (DataH >> 8);
    gRxCAN.BUF[6] = (u32)0x000000FF & (DataH >> 16);
    gRxCAN.BUF[7] = (u32)0x000000FF & (DataH >> 24);
    CanOpenRxPres();
  }
  gMessagePending = 0;
}
/****************************************************************************
* ���ƣ�Ctx(void)
* ���ܣ�CAN��������
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void  Ctx(void)
{
  MCO_ProcessStack();
}

/****************************************************************************
* ���ƣ�USB_LP_CAN1_RX0_IRQHandler(void)
* ���ܣ�CAN�����жϷ�����
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  gMessagePending = CAN_MessagePending(CAN1,CAN_FIFO0);
  Crx();
}

