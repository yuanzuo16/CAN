
#ifndef I2C_24C16_H
#define I2C_24C16_H 1

#include "stm32f10x.h"
//#include "stm32f10x_type.h"
//#include "stm32f10x_lib.h"

//---------------pin decription------------------------
#define I2C_24C16 I2C1

//---------------I2C configuration--------------------
#define I2C_Speed 10000

// I2c Adress, 24C16 got no Adress Pin Optional
#define I2C_Slave_Adress7 0xA0 
#define I2C_Pagesize 16
#define I2C_24C 10 

// 4 Parts Address Definition
#define EE24C_Block0_ADDR  0xA0
#define EE24C_Block1_ADDR  0xA2
#define EE24C_Block2_ADDR  0xA4
#define EE24C_Block3_ADDR  0xA6

#define EE24C_TxBuf_SIZE 16
#define EE24C_RxBuf_SIZE 16

//---------------24C16/08/04/02  API----------------
void i2c_24c_init(I2C_TypeDef *I2Cx);

void i2c_24c_byte_write(unsigned char Byte, unsigned char WriteAddr, unsigned int ByteToWrite, unsigned char EE24cBlockSelect,I2C_TypeDef *I2Cx);

void i2c_24c_buffer_write(unsigned char *pBuffer, unsigned char WriteAddr, unsigned int ByteToWrite, unsigned char EE24cBlockSelect,I2C_TypeDef *I2Cx);

void i2c_24c_page_wrtie(unsigned char *pBuffer, unsigned char Addr, unsigned char ByteToWrite,unsigned char EE24cBlockSelect, I2C_TypeDef *I2Cx);

void i2c_24c_buffer_read(unsigned char *pBuffer, unsigned char Addr,unsigned int NumToRead,unsigned char EE24cBlockSelect, I2C_TypeDef *I2Cx);

void i2c_24c_wait(unsigned char EE24cBlockSelect, I2C_TypeDef *I2Cx);

#endif
