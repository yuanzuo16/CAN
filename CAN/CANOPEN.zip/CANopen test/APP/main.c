/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "delay.h"
#include "can.h"
#include "mco.h"
#include "lcd.h"
#include "bsp.h"
#include "i2c.h"
#include "24cxx.h"
#include "stdio.h"

typedef struct
{
  u8 BaudRate_Data;
  u8 ODNodeID_Data;
}e2prom;
e2prom Image;
#define SIZE sizeof(Image)

void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void SYS_Tick_Configuration(void);
void Set_Task(void);

u32 *pDataIn,*pDataIna;
u32  Datain,Dataina;
u8   Key0_Flag=RESET;
u8   Set_Flag=0;
u8   KeyUp_Flag=RESET;
u8   Baud_Data=0x01;
u16 setData=0x45;
extern OD_TABLE OD[MAX_OD_SIZE];
extern WORD volatile gTimCnt;
extern BYTE ODNodeID;

int main(void)
{
  RCC_Configuration();
  GPIO_Configuration();
  delay_init();
  LCD_Init();
  LCD_Fill(0,0,239,319,BRED);
  POINT_COLOR=RED;       //�����ɫ
  LCD_ShowString(30,50,200,16,16,"zhanjian STM32 ^_^");
  LCD_ShowString(30,70,200,16,16,"CAN TEST");
  LCD_ShowString(30,90,200,16,16,"wang xiao xin zhi zuo");
  LCD_ShowString(30,110,200,16,16,"2014/03/24");
  LCD_ShowString(60,130,200,16,16,"Datain:");  //8*7=56+8=64
  LCD_ShowString(60,150,200,16,16,"Datain:");  //8*7=56+8=64
  LCD_ShowString(60,170,200,16,16,"BaudRate:");//8*9=72+8=80
  LCD_ShowString(60,190,200,16,16,"ODNodeID:");
  /**����e2promֵ����Set_Task()���ж��Ƿ�Ҫ�������ò����ʺ�ID**/
  while(AT24CXX_Check());//�˲鲨���ʺ�ID�ڲ��ڷ�Χ��
  AT24CXX_Read(0,(u8*)&Image,SIZE);//��ȡe2prom
  ODNodeID=Image.ODNodeID_Data;
  Baud_Data=Image.BaudRate_Data;
  SYS_Tick_Configuration();
  NVIC_Configuration();
  CAN_Configration(Baud_Data);
  MCOUSER_ResetCommunication();
  OD[83].Val = setData;
  pDataIn = &OD[MCO_Search_ODTABLE(0x6001,0x02)].Val;
  while (1)
  {
    pDataIna=&OD[MCO_Search_ODTABLE(0x2002,0x03)].Val;
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==SET)
    {
      if(KeyUp_Flag==RESET)
      {
        KeyUp_Flag=SET;
        Set_Task();
      }
    }
    else{ KeyUp_Flag=RESET;}
    Ctx();
    Datain = *pDataIn;
    Dataina = *pDataIna;
    LCD_ShowxNum(124,130,Datain,4,16,0);           //��ʾDatain��ֵ
    LCD_ShowxNum(124,150,Dataina,4,16,0);           //��ʾDatain��ֵ
    LCD_ShowxNum(140,170,Baud_Data,4,16,0);        //��ʾBaudRate��ֵ
    LCD_ShowxNum(140,190,ODNodeID,4,16,0);         //��ʾODNodeID��ֵ 
  }
}

/****************************************************************************
* ���ƣ�RCC_Configuration()
* ���ܣ�����ϵͳʱ�ӣ�ʹ��ʹ�õ�ʱ��
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void RCC_Configuration(void)
{
  SystemInit();
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
}

/*******************************************************************************
*�������ƣ�void SYS_Tick_Configuration(void)
*�������ܣ�ϵͳ�δ�ʱ�ӵ�����
*��ڲ�������
*���ڲ�������
*******************************************************************************/
void SYS_Tick_Configuration(void)
{
  SysTick->CTRL &= (u32)0xFFFFFFFE;   //ʧ��ϵͳ�δ������	
  SysTick->CTRL &= (u32)0xFFFFFFFD;   //ʧ���ж�
  SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);//����ʱ��Ϊ9M
  SysTick->LOAD = 9000;               //��������װ��ֵ
  SysTick->CTRL |= (u32)0x00000001;   //ʹ��ϵͳ�δ�ʱ��
  SysTick->CTRL |= (u32)0x00000002;   //ʹ���ж�
}
/****************************************************************************
* ���ƣ�GPIO_Configuration(void)
* ���ܣ���������
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  //CAN  I/O��ʼ��
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_11;//RX
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
  GPIO_Init(GPIOA,&GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_12;//TX
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA,&GPIO_InitStructure);
  //LED I/O��ʼ��
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB,&GPIO_InitStructure);
  GPIO_SetBits(GPIOB,GPIO_Pin_5);
    
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOE,&GPIO_InitStructure);
  GPIO_SetBits(GPIOE,GPIO_Pin_5);
  //KEY I/O��ʼ��
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  //IIC I/O��ʼ��
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;   //�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_SetBits(GPIOB,GPIO_Pin_10|GPIO_Pin_11); 	//PB10,PB11 ����� 
}


/****************************************************************************
* ���ƣ�NVIC_Configuration(void)
* ���ܣ������ж����ȼ�
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure; 
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1); 

  NVIC_SetPriority (SysTick_IRQn, 0);
  
  NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn; 
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2; 
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
  NVIC_Init(&NVIC_InitStructure);
}

/****************************************************************************
* ���ƣ�void SysTickHandler(void)
* ���ܣ��δ�ʱ���������
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void SysTick_Handler(void)
{
  gTimCnt++;
}

/****************************************************************************
* ���ƣ�void Set_Task(void)
* ���ܣ����ò����ʺ�ID��
* ��ڲ�������
* ���ڲ�������
****************************************************************************/
void Set_Task(void)
{
  while(1)
    {
      if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)==RESET)//key0����
      {
        if(Key0_Flag==RESET)
        {
            Key0_Flag=SET;
            Set_Flag++;
            //if(Set_Flag==4) Set_Flag=0;
        }
      }
      else Key0_Flag=RESET;
      if(Set_Flag==1)//����ODNodeID
      {
        Key_ReceiveODNodeID();
      }
      if(Set_Flag==2)//����BaudRate
      {
        //CAN_Configration(Key_ReceiveBaudRate());
        Baud_Data = Key_ReceiveBaudRate();
      }
      if(Set_Flag==3)//ȷ������
      {
        Set_Flag=0;
        Image.ODNodeID_Data = ODNodeID;
        Image.BaudRate_Data = Baud_Data;
        AT24CXX_Write(0,(u8*)&Image,SIZE);//д��e2prom
        SYS_Tick_Configuration();
        NVIC_Configuration();
        CAN_Configration(Baud_Data);
        MCOUSER_ResetCommunication();
        pDataIn = &OD[MCO_Search_ODTABLE(0x6001,0x02)].Val;
        break;
      }
    LCD_ShowxNum(140,150,Baud_Data,4,16,0); //��ʾBaudRate��ֵ
    LCD_ShowxNum(140,170,ODNodeID,4,16,0);         //��ʾODNodeID��ֵ 
    }
}
